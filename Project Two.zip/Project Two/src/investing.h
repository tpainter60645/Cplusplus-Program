/*
 * investing.h
 *
 *  Created on: Jun 4, 2020
 *      Author: Tim Painter
 */

#ifndef INVESTING_H_
#define INVESTING_H_

//create class and assign variables
class investing{
public:
	investing(double intialInvestment, double monthlyInvestment, double rate, int years);
	virtual~investing();
	void noMonthlyDeposit();
	void withMonthlyDeposit();

private:
	double initialInvestment;
	double monthlyInvestment;
	int numYears;
	double interestRate;

};



#endif /* INVESTING_H_ */
