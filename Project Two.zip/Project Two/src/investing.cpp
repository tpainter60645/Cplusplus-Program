/*
 * investing.cpp
 *
 *  Created on: Jun 4, 2020
 *      Author: Tim Painter
 */

#include<iomanip>
#include<iostream>
#include "investing.h"
using namespace std;

//set values for variables for constructor
investing::investing(double initInvestment, double monthlyInvestment, double rate, int years){
	this->initialInvestment = initInvestment;
	this->monthlyInvestment = monthlyInvestment;
	this->interestRate = rate;
	this->numYears = years;
}
//destructor
investing::~investing(){

}
//prints header and report for no monthly deposit
void investing::noMonthlyDeposit(){
	cout << "          Balance and interest without additional monthly deposits" << endl;
	cout << "=========================================================================" << endl;
	cout << setw(10) << "Year" << setw(20) << "Year End Balance" << setw(35) << "Year End Earned Interest Rate" << endl;

    cout << "--------------------------------------------------------------------------" << endl;


int currentYear = 1;
double yearEndBalance = this->initialInvestment;

//calculates interest monthly and compounded
while(currentYear <= this->numYears){
	double intEarned = yearEndBalance * this -> interestRate / 100;
	yearEndBalance += intEarned;
	cout << right << setw(10) << currentYear << fixed << setprecision(2) << setw(20) << yearEndBalance << setw(35) << intEarned << endl;
	currentYear++;

}
}
//prints header and report for monthly deposit
void investing::withMonthlyDeposit(){
	cout << "             Balance and interest with monthly deposit" << endl;
	cout << "==========================================================================" << endl;
	cout << setw(10) << "Year" << setw(20) << "Year End Balance" << setw(35) << "Year End Earned Interest Rate" << endl;
    cout << "--------------------------------------------------------------------------" << endl;

    int currentYear = 1;
    double yearEndBalance = this->initialInvestment;

    //calculates interest monthly and compounded
    while(currentYear <= this->numYears){
    	int month = 1;

    	double intEarned = 0.0;
    	double monthEndBalance = yearEndBalance;

    	while(month <= 12){
    	    monthEndBalance += this->monthlyInvestment;
    		double monthlyInterest = monthEndBalance * this-> interestRate/(100*12);
    		intEarned += monthlyInterest;
    		monthEndBalance += monthlyInterest;
    		month++;
    	}
    	yearEndBalance = monthEndBalance;
    	cout << right << setw(10) << currentYear << fixed << setprecision(2) << setw(20) << yearEndBalance << setw(35) << intEarned << endl;
    	currentYear++;
    	}
}
