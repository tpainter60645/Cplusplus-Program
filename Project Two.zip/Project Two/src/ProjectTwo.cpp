/*
 * ProjectTwo.cpp
 *
 *  Created on: Jun 4, 2020
 *      Author: Tim Painter
 */

#include <iostream>
#include "investing.h"
using namespace std;

//getting user input.  Displays required headers
int main(){
	while (1){
		//getting user input
		cout << "********************************************************" << endl;
		cout << "**********************Data Input************************" << endl;
		cout << "Initial Investment Amount: $";
		double initDeposit, monthlyDeposit, interestRate;
		int years;
		cin >> initDeposit;
		cout << "Monthly Deposit: $";
		cin >> monthlyDeposit;
		cout << "Annual Interest: %";
		cin >> interestRate;
		cout << "Number of Years: ";
		cin >> years;

		system("pause");//pauses system and instructs user to continue by hitting any key


		//investing objects dependent on user inputs
		investing myInvesting = investing(initDeposit, monthlyDeposit, interestRate, years);
		cout << endl;
		myInvesting.noMonthlyDeposit();
	    cout << endl;

	   if(monthlyDeposit > 0){
	    	myInvesting.withMonthlyDeposit();
	    }
	    else if (monthlyDeposit == 0){
	    	        cout << endl << "******If you just invested $10 a month, this is how your money would grow!******" << endl << endl;
	    			monthlyDeposit = 10;
	    			investing myInvesting = investing(initDeposit, monthlyDeposit, interestRate, years);
	    	    	myInvesting.withMonthlyDeposit();

	    	    }
	    //give user option to do another or exit
	    cout << endl << "Would you like to try another? (y/n):";
	    string choice;
	    cin >> choice;
	    if(choice != "y"){
	    	break;
	    }
	    cout << endl;
		}
	return 0;
}


